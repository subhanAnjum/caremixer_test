package com.example.caremixer_assessment

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
